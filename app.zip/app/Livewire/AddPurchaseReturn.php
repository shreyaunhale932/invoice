<?php

namespace App\Livewire;

use Livewire\Component;

class AddPurchaseReturn extends Component
{
    public function render()
    {
        return view('livewire.add-purchase-return');
    }
}
