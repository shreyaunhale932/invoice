<?php

namespace App\Livewire;

use Livewire\Component;

class IndexCards extends Component
{
    public function render()
    {
        return view('livewire.index-cards');
    }
}
