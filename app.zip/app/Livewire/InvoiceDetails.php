<?php

namespace App\Livewire;

use Livewire\Component;

class InvoiceDetails extends Component
{
    public function render()
    {
        return view('livewire.invoice-details');
    }
}
