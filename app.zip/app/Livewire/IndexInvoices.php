<?php

namespace App\Livewire;

use Livewire\Component;

class IndexInvoices extends Component
{
    public function render()
    {
        return view('livewire.index-invoices');
    }
}
