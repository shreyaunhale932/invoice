<?php

namespace App\Livewire;

use Livewire\Component;

class InvoiceFive extends Component
{
    public function render()
    {
        return view('livewire.invoice-five');
    }
}
