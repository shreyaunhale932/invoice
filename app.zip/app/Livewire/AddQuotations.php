<?php

namespace App\Livewire;

use Livewire\Component;

class AddQuotations extends Component
{
    public function render()
    {
        return view('livewire.add-quotations');
    }
}
