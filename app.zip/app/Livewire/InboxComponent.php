<?php

namespace App\Livewire;

use Livewire\Component;

class InboxComponent extends Component
{
    public function render()
    {
        return view('livewire.inbox-component');
    }
}
