<?php

namespace App\Livewire;

use Livewire\Component;

class TemplateInvoice extends Component
{
    public function render()
    {
        return view('livewire.template-invoice');
    }
}
