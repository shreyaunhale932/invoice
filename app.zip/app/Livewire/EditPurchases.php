<?php

namespace App\Livewire;

use Livewire\Component;

class EditPurchases extends Component
{
    public function render()
    {
        return view('livewire.edit-purchases');
    }
}
