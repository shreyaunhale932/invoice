<?php

namespace App\Livewire;

use Livewire\Component;

class AddInvoice extends Component
{
    public function render()
    {
        return view('livewire.add-invoice');
    }
}
