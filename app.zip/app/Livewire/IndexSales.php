<?php

namespace App\Livewire;

use Livewire\Component;

class IndexSales extends Component
{
    public function render()
    {
        return view('livewire.index-sales');
    }
}
