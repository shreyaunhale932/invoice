<?php

namespace App\Livewire;

use Livewire\Component;

class EditCreditNotes extends Component
{
    public function render()
    {
        return view('livewire.edit-credit-notes');
    }
}
