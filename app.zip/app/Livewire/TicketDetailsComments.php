<?php

namespace App\Livewire;

use Livewire\Component;

class TicketDetailsComments extends Component
{
    public function render()
    {
        return view('livewire.ticket-details-comments');
    }
}
