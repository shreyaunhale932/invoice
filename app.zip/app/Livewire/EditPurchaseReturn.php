<?php

namespace App\Livewire;

use Livewire\Component;

class EditPurchaseReturn extends Component
{
    public function render()
    {
        return view('livewire.edit-purchase-return');
    }
}
