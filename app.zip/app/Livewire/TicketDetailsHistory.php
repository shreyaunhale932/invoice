<?php

namespace App\Livewire;

use Livewire\Component;

class TicketDetailsHistory extends Component
{
    public function render()
    {
        return view('livewire.ticket-details-history');
    }
}
