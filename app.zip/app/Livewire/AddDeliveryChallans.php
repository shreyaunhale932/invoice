<?php

namespace App\Livewire;

use Livewire\Component;

class AddDeliveryChallans extends Component
{
    public function render()
    {
        return view('livewire.add-delivery-challans');
    }
}
