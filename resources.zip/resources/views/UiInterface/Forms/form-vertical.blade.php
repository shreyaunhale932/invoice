<?php $page = 'form-vertical'; ?>
@extends('layout.mainlayout')
@section('content')
			<!-- Page Wrapper -->
            <div class="page-wrapper">
			
				<div class="content container-fluid">

					<!-- Page Header -->
					<div class="page-header">
						<div class="content-page-header">
							<h5>Vertical Form</h5>
						</div>	
					</div>
					<!-- /Page Header -->

					<div class="row">
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Basic Form</h5>
								</div>
								<div class="card-body">
									<form action="#">
										<div class="input-block mb-3">
											<label>First Name</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Last Name</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Email Address</label>
											<input type="email" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Username</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Password</label>
											<input type="password" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Repeat Password</label>
											<input type="password" class="form-control">
										</div>
										<div class="text-end">
											<button type="submit" class="btn btn-primary">Submit</button>
										</div>
									</form>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Address Form</h5>
								</div>
								<div class="card-body">
									<form action="#">
										<div class="input-block mb-3">
											<label>Address Line 1</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Address Line 2</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>City</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>State</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Country</label>
											<input type="text" class="form-control">
										</div>
										<div class="input-block mb-3">
											<label>Postal Code</label>
											<input type="text" class="form-control">
										</div>
										<div class="text-end">
											<button type="submit" class="btn btn-primary">Submit</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Two Column Vertical Form</h5>
								</div>
								<div class="card-body">
									<form action="#">
										<h5 class="card-title">Personal Information</h5>
										<div class="row">
											<div class="col-md-6">
												<div class="input-block mb-3">
													<label>First Name</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Last Name</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Blood Group</label>
													<select class="select">
														<option>Select</option>
														<option value="1">A+</option>
														<option value="2">O+</option>
														<option value="3">B+</option>
														<option value="4">AB+</option>
													</select>
												</div>
												<div class="input-block mb-3">
													<label class="d-block">Gender:</label>
													<div class="form-check form-check-inline">
														<input class="form-check-input" type="radio" name="gender" id="gender_male" value="option1">
														<label class="form-check-label" for="gender_male">Male</label>
													</div>
													<div class="form-check form-check-inline">
														<input class="form-check-input" type="radio" name="gender" id="gender_female" value="option2">
														<label class="form-check-label" for="gender_female">Female</label>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="input-block mb-3">
													<label>Username</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Email</label>
													<input type="text" class="form-control">
												</div>

												<div class="input-block mb-3">
													<label>Password</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Repeat Password</label>
													<input type="text" class="form-control">
												</div>
											</div>
										</div>
										<h5 class="card-title">Postal Address</h5>
										<div class="row">
											<div class="col-md-6">
												<div class="input-block mb-3">
													<label>Address Line 1</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Address Line 2</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>State</label>
													<input type="text" class="form-control">
												</div>
											</div>
											<div class="col-md-6">
												<div class="input-block mb-3">
													<label>City</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Country</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Postal Code</label>
													<input type="text" class="form-control">
												</div>
											</div>
										</div>
										<div class="text-end">
											<button type="submit" class="btn btn-primary">Submit</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Two Column Vertical Form</h5>
								</div>
								<div class="card-body">
									<form action="#">
										<div class="row">
											<div class="col-md-6">
												<h5 class="card-title">Personal details</h5>
												<div class="input-block mb-3">
													<label>Name:</label>
													<input type="text" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>Password:</label>
													<input type="password" class="form-control">
												</div>
												<div class="input-block mb-3">
													<label>State:</label>
													<select class="select">
														<option>Select State</option>
														<option value="1">California</option>
														<option value="2">Texas</option>
														<option value="3">Florida</option>
													</select>
												</div>
												<div class="input-block mb-3">
													<label>Your Message:</label>
													<textarea rows="5" cols="5" class="form-control" placeholder="Enter message"></textarea>
												</div>
											</div>
											<div class="col-md-6">
												<h5 class="card-title">Personal details</h5>
												<div class="row">
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>First Name:</label>
															<input type="text" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>Last Name:</label>
															<input type="text" class="form-control">
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>Email:</label>
															<input type="text" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>Phone:</label>
															<input type="text" class="form-control">
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-12">
														<div class="input-block mb-3">
															<label>Address line:</label>
															<input type="text" class="form-control">
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>Country:</label>
															<select class="select">
																<option>Select Country</option>
																<option value="1">USA</option>
																<option value="2">France</option>
																<option value="3">India</option>
																<option value="4">Spain</option>
															</select>
														</div>
													</div>
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>State/Province:</label>
															<input type="text" class="form-control">
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>ZIP code:</label>
															<input type="text" class="form-control">
														</div>
													</div>
													<div class="col-md-6">
														<div class="input-block mb-3">
															<label>City:</label>
															<input type="text" class="form-control">
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="text-end">
											<button type="submit" class="btn btn-primary">Submit</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			<!-- /Page Wrapper -->
@endsection