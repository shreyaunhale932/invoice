<?php $page = 'maps-vector'; ?>
@extends('layout.mainlayout')
@section('content')
    <!-- Page Wrapper -->
    <div class="page-wrapper">

        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="content-page-header">
                    <h5>Vector Maps</h5>
                </div>
            </div>
            <!-- /Page Header -->

            <!-- World Map -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">World Map</h5>
                        </div>
                        <div class="card-body">
                            <div id="world_map" style="height: 400px"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /World Map -->

            <div class="row">
                <div class="col-lg-6">
                    <!-- USA Map -->
                    <div class="card bg-white">
                        <div class="card-header">
                            <h5 class="card-title">USA Map</h5>
                        </div>
                        <div class="card-body">
                            <div id="usa" style="height: 400px"></div>
                        </div>
                    </div>
                    <!-- /USA Map -->
                </div>
                <div class="col-lg-6">
                    <!-- UK Map -->
                    <div class="card bg-white">
                        <div class="card-header">
                            <h5 class="card-title">UK Map</h5>
                        </div>
                        <div class="card-body">
                            <div id="uk" style="height: 400px"></div>
                        </div>
                    </div>
                    <!-- /UK Map -->
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <!-- India Map -->
                    <div class="card bg-white mb-0">
                        <div class="card-header">
                            <h5 class="card-title">India Map</h5>
                        </div>
                        <div class="card-body">
                            <div id="india" style="height: 400px"></div>
                        </div>
                    </div>
                    <!-- /India Map -->
                </div>
                <div class="col-lg-6">
                    <!-- Russia Map -->
                    <div class="card bg-white mb-0">
                        <div class="card-header">
                            <h5 class="card-title">Russia Map</h5>
                        </div>
                        <div class="card-body">
                            <div id="russia" style="height: 400px"></div>
                        </div>
                    </div>
                    <!-- /Russia Map -->
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Wrapper -->
@endsection
