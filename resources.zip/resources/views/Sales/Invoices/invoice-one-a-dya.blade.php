<?php $page = 'invoice-one-a'; ?>
@extends('layout.mainlayout')
@section('content')
@php
    use App\Helpers\NumberHelper;
@endphp
<style>
/* =========================
   PRINT FIX – ADD ONLY
   ========================= */
   .container,
    .container-fluid {
        max-width: none !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    .invoice-wrapper{
        max-width: none !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }
@media print {
     .company-details {
    background: var(--color-gradient, linear-gradient(320deg, #DBECFF 0%, #DDCEFF 100%)) !important;
    border-radius: 14px 77px 14px 14px !important;
}

}
/* =====================================================
   PRINT CSS – ULTRA COMPACT (ALL INVOICES)
   ===================================================== */
@media print {

    /* -----------------------------
       PAGE RESET
       ----------------------------- */
    html, body {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        height: 100% !important;
        font-size: 9.5px !important;
        line-height: 1.2 !important;
        font-family: Arial, Helvetica, sans-serif !important;
    }

    /* Hide everything except invoice */
    body * {
        visibility: hidden !important;
    }

    .download_section,
    .download_section * {
        visibility: visible !important;
    }

    /* -----------------------------
       CONTAINER / WRAPPER
       ----------------------------- */
    .container,
    .container-fluid,
    .invoice-one,
    .invoice-wrapper {
        max-width: 100% !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .download_section {
        position: absolute;
        top: 0;
        left: 0;
        width: 210mm !important;
        min-height: 297mm;
        padding: 6mm !important;
        background: #fff !important;
    }

    /* -----------------------------
       HEADINGS
       ----------------------------- */
       .add-details{
        font-size: 9.5px !important;
       }
       .invoice-table-footer{
        padding: 0px !important;
       }
    h4 {
        font-size: 15px !important;
        margin: 0 0 3px !important;
    }

    h5 {
        font-size: 11px !important;
        margin: 0 0 4px !important;
    }

    h6 {
        font-size: 9.5px !important;
        margin: 0 0 2px !important;
    }
    span{
        font-size: 9.5px !important;
    }

    p {
        margin: 0 0 3px !important;
        font-size: 9px !important;
    }

    /* -----------------------------
       HEADER COMPRESSION
       ----------------------------- */
    .invoice-header {
        margin-bottom: 6px !important;
        padding-bottom: 4px !important;
    }

    .invoice-one .inv-content .invoice-header .inv-header-left {
        width: 60% !important;
    }

    .company-details {
        padding: 6px !important;
        border-radius: 10px 55px 10px 10px !important;
    }

    .gst-details {
        padding: 8px 12px !important;
        margin: 0 !important;
        color: #fff !important;
    }

    /* LOGO – MUCH SMALLER */
    .invoice-one .inv-header-right a img {
        max-width: 140px !important;
        margin-bottom: 4px !important;
    }

    /* -----------------------------
       CUSTOMER INFO
       ----------------------------- */
    .patient-infos {
        margin-bottom: 6px !important;
    }

    .patient-detailed {
        padding: 4px !important;
    }

    .bill-add {
        font-size: 9px !important;
        margin-bottom: 1px !important;
    }

    .customer-name,
    .payment-status {
        font-size: 9px !important;
    }

    /* -----------------------------
       TABLE COMPRESSION
       ----------------------------- */
    table {
        width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
    }

    thead {
        display: table-header-group;
    }

    th {
        font-size: 10px !important;
        padding: 3px !important;
    }

    td {
        font-size: 10px !important;
        padding: 3px !important;
        word-break: break-word;
    }

    tr {
        page-break-inside: avoid;
    }
    .invoice-one .invoice-table table tr td {
        height: 30px !important;
    }
    .invoice-one .invoice-table {
    margin: 0 !important;
    padding: 0 0 0px !important;
}
.invoice-one .inv-content {
    border: 1px solid #BDBDBD;
    margin: 0 !important;
    padding: 10px !important;
}
    /* -----------------------------
       TOTALS / PAYMENT BLOCKS
       ----------------------------- */
    .invoice-table-footer {
        margin-top: 4px !important;
        padding-top: 4px !important;
        page-break-inside: avoid;
    }

    .invoice-table-footer table td {
        font-size: 10px !important;
        padding: 2px 3px !important;
    }

    .totalamount-footer td {
        font-size: 10px !important;
    }

    /* -----------------------------
       QR + TERMS
       ----------------------------- */
    .qr img {
        max-width: 70px !important;
    }

    .scan-details {
        font-size: 8.5px !important;
        margin-top: 2px !important;
    }

    .terms-condition ol {
        padding-left: 12px !important;
        margin: 0 !important;
    }

    .terms-condition li {
        font-size: 8.5px !important;
        line-height: 1.2 !important;
    }

    /* -----------------------------
       FINAL MESSAGE
       ----------------------------- */
    .thanks-msg {
        font-size: 9px !important;
        margin-top: 6px !important;
        text-align: center;
    }

    /* -----------------------------
       HIDE ACTION BUTTONS
       ----------------------------- */
    .file-link {
        display: none !important;
    }

    /* -----------------------------
       PRESERVE COLORS
       ----------------------------- */
    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
        .invoice-table-footer .notes img {
        max-width: 70px !important;
    }

    /* -----------------------------
       PAGE SETUP
       ----------------------------- */
    @page {
        size: A4;
        margin: 0;
    }
}

</style>


    <div class="container">
        <div class="invoice-wrapper download_section">
            <div class="inv-content">
                <span class="line"></span>
                @php
                /* =====================================================
                 | HEADER / COMPANY TEXT VALUES
                 ===================================================== */
                $invoiceTitle = $templateSettings['invoice_header.title']->label ?? 'Invoice';

                $companyName = $templateSettings['text_elements.company_name']->value
                    ?? $templateSettings['text_elements.company_name']->default_value
                    ?? '';

                $companyAddress = $templateSettings['text_elements.company_address']->value
                    ?? $templateSettings['text_elements.company_address']->default_value
                    ?? '';

                /* =====================================================
                 | HEADER VISIBILITY FLAGS
                 ===================================================== */
                $invoiceTitleVisible   = $templateSettings['invoice_header.title']->is_visible ?? true;
                $companyNameVisible    = $templateSettings['text_elements.company_name']->is_visible ?? true;
                $companyAddressVisible = $templateSettings['text_elements.company_address']->is_visible ?? true;

                $logoLightVisible = $templateSettings['visual_elements.logo_light']->is_visible ?? true;
                $logoDarkVisible  = $templateSettings['visual_elements.logo_dark']->is_visible ?? true;

                $invoiceNoVisible   = $templateSettings['invoice_meta.invoice_no']->is_visible ?? true;
                $invoiceDateVisible = $templateSettings['invoice_meta.invoice_date']->is_visible ?? true;
                $dueDateVisible     = $templateSettings['invoice_meta.due_date']->is_visible ?? true;

                /* =====================================================
                 | LOGOS
                 ===================================================== */
                $logoLight = $templateSettings['visual_elements.logo_light']->value
                    ?? $templateSettings['visual_elements.logo_light']->default_value
                    ?? '/public/assets/img/logo2.png';

                $logoDark = $templateSettings['visual_elements.logo_dark']->value
                    ?? $templateSettings['visual_elements.logo_dark']->default_value
                    ?? '/public/assets/img/logo2-white.png';

                /* =====================================================
                 | INVOICE META LABELS
                 ===================================================== */
                $invoiceNoLabel   = $templateSettings['invoice_meta.invoice_no']->label ?? 'Invoice No';
                $invoiceDateLabel = $templateSettings['invoice_meta.invoice_date']->label ?? 'Invoice Date';
                $dueDateLabel     = $templateSettings['invoice_meta.due_date']->label ?? 'Due Date';

                /* =====================================================
                 | CUSTOMER INFO VALUES & VISIBILITY
                 ===================================================== */
                $customerInfoVisible      = $templateSettings['customer_info.section_title']->is_visible ?? true;
                $customerDetailsVisible   = $templateSettings['customer_info.customer_details_label']->is_visible ?? true;
                $billingVisible           = $templateSettings['customer_info.billing_address_label']->is_visible ?? true;
                $shippingVisible          = $templateSettings['customer_info.shipping_address_label']->is_visible ?? true;
                $paymentStatusVisible     = $templateSettings['customer_info.payment_status_label']->is_visible ?? true;
                $gstinVisible             = $templateSettings['customer_info.gstin_label']->is_visible ?? true;

                $sectionTitle         = $templateSettings['customer_info.section_title']->label ?? 'Customer Information';
                $customerDetailsLabel = $templateSettings['customer_info.customer_details_label']->label ?? 'Customer Details';
                $billingAddressLabel  = $templateSettings['customer_info.billing_address_label']->label ?? 'Billing Address';
                $shippingAddressLabel = $templateSettings['customer_info.shipping_address_label']->label ?? 'Shipping Address';
                $paymentStatusLabel   = $templateSettings['customer_info.payment_status_label']->label ?? 'Payment Status';
                $gstinLabel           = $templateSettings['customer_info.gstin_label']->label ?? 'GSTIN';
                @endphp


                {{-- ================= HEADER ================= --}}
                <div class="invoice-header">

                    {{-- LEFT --}}
                    @if($invoiceTitleVisible || $companyNameVisible || $companyAddressVisible)
                    <div class="inv-header-left">

                        @if($invoiceTitleVisible)
                            <h4>Sell Invoice</h4>
                        @endif

                        @if($companyNameVisible || $companyAddressVisible)
                        <div class="company-details">
                            <div class="gst-details">

                                @if($companyNameVisible)
                                    <h6>{{ $companyName }}</h6>
                                @endif

                                @if($companyAddressVisible)
                                    <span>{!! nl2br(e($companyAddress)) !!}</span>
                                @endif

                            </div>
                            <div class="address-bg"></div>
                        </div>
                        @endif

                    </div>
                    @endif

                    {{-- RIGHT --}}
                    @if($logoLightVisible || $logoDarkVisible || $invoiceNoVisible || $invoiceDateVisible || $dueDateVisible)
                    <div class="inv-header-right">

                        @if($logoLightVisible || $logoDarkVisible)
                        <a href="javascript:void(0)">
                            @if($logoLightVisible)
                                <img class="logo-lightmode" src="{{ asset($logoLight) }}" alt="Logo">
                            @endif
                            @if($logoDarkVisible)
                                <img class="logo-darkmode" src="{{ asset($logoDark) }}" alt="Logo">
                            @endif
                        </a>
                        @endif

                        @if($invoiceNoVisible)
                        <h6>
                            {{ $invoiceNoLabel }} :
                            <span>#{{ $invoice->invoice_no }}</span>
                        </h6>
                        @endif

                        @if($invoiceDateVisible)
                        <h6>
                            {{ $invoiceDateLabel }} :
                            <span>{{ date('d-m-Y', strtotime($invoice->invoice_date)) }}</span>
                        </h6>
                        @endif

                        @if($dueDateVisible)
                        <p>
                            <span>
                                {{ $dueDateLabel }} :
                                {{ date('d-m-Y', strtotime($invoice->invoice_due_date)) }}
                            </span>
                        </p>
                        @endif

                    </div>
                    @endif
                </div>

                @if($invoiceTitleVisible || $companyNameVisible || $companyAddressVisible)
                <span class="line"></span>
                @endif


                {{-- ================= CUSTOMER INFO ================= --}}
                @if($customerInfoVisible)

                <h5>{{ $sectionTitle }}</h5>

                <div class="patient-infos">
                    <div class="row">

                        {{-- CUSTOMER DETAILS --}}
                        @if($customerDetailsVisible)
                        <div class="col-sm-4">
                            <div class="patient-detailed">
                                <div class="bill-add">
                                    {{ $customerDetailsLabel }} :
                                </div>

                                <div class="customer-name">
                                    {{ $customer->name }}

                                    @if($gstinVisible && !empty($customer->gstin))
                                        <p>
                                            <span>{{ $gstinLabel }} : {{ $customer->gstin }}</span>
                                        </p>
                                    @endif
                                </div>

                                @if($paymentStatusVisible)
                                <div class="payment-status">
                                    {{ $paymentStatusLabel }}
                                    <p>
                                        <span>{{ $invoice->status ?? 'Pending' }}</span>
                                    </p>
                                </div>
                                @endif
                            </div>
                        </div>
                        @endif

                        {{-- BILLING ADDRESS --}}
                        @if($billingVisible)
                        <div class="col-sm-4">
                            <div class="patient-detailed">
                                <div class="bill-add">
                                    {{ $billingAddressLabel }} :
                                </div>
                                <div class="add-details">
                                    {{ $customer->address1 }}
                                </div>
                            </div>
                        </div>
                        @endif

                        {{-- SHIPPING ADDRESS --}}
                        {{-- @if($shippingVisible)
                        <div class="col-sm-4">
                            <div class="patient-detailed">
                                <div class="bill-add">
                                    {{ $shippingAddressLabel }} :
                                </div>
                                <div class="add-details">
                                    {{ $invoice->shipping_address ?: $customer->address1 }}
                                </div>
                            </div>
                        </div>
                        @endif --}}

                    </div>
                </div>

                @endif


                @php
                $columnLabels = [
                    'sr_no'         => $templateSettings['item_table.column_sr_no']->label ?? '#',
                    'category'      => $templateSettings['item_table.column_category']->label ?? 'Category',
                    'subcategory'   => $templateSettings['item_table.column_subcategory']->label ?? 'Sub Category',
                    'item'          => $templateSettings['item_table.column_item']->label ?? 'Item',
                    'pre_code'      => $templateSettings['item_table.column_pre_code']->label ?? 'Pre Code',
                    'post_code'     => $templateSettings['item_table.column_post_code']->label ?? 'Post Code',
                    'barcode'       => $templateSettings['item_table.column_barcode']->label ?? 'Barcode',
                    'hsn_code'      => $templateSettings['item_table.column_hsn_code']->label ?? 'HSN Code',
                    'purity'        => $templateSettings['item_table.column_purity']->label ?? 'Purity',
                    'qty'           => $templateSettings['item_table.column_qty']->label ?? 'Qty',
                    'metal_rate'    => $templateSettings['item_table.column_metal_rate']->label ?? 'Metal Rate',
                    'gross_wt'      => $templateSettings['item_table.column_gross_wt']->label ?? 'Gross Wt',
                    'net_wt'        => $templateSettings['item_table.column_net_wt']->label ?? 'Net Wt',
                    'fine_wt'       => $templateSettings['item_table.column_fine_wt']->label ?? 'Fine Wt',
                    'size'          => $templateSettings['item_table.column_size']->label ?? 'Size',
                    'wastage'       => $templateSettings['item_table.column_wastage_percent']->label ?? 'Wastage %',
                    'making'        => $templateSettings['item_table.column_making']->label ?? 'Making',
                    'gst_percent'   => $templateSettings['item_table.column_gst_percent']->label ?? 'GST %',
                    'gst_amount'    => $templateSettings['item_table.column_gst_amount']->label ?? 'GST Amount',
                    'other_charges' => $templateSettings['item_table.column_other_charges']->label ?? 'Other Charges',
                    'diamond_amount' => $templateSettings['item_table.column_diamond_amount']->label ?? 'Diamond Amount',
                    'stone_amount' => $templateSettings['item_table.column_stone_amount']->label ?? 'Stone Amount',
                    'amount'        => $templateSettings['item_table.column_amount']->label ?? 'Amount',
                ];

                $columnVisibility = [
                    'sr_no'         => $templateSettings['item_table.column_sr_no']->is_visible ?? true,
                    'category'      => $templateSettings['item_table.column_category']->is_visible ?? true,
                    'subcategory'   => $templateSettings['item_table.column_subcategory']->is_visible ?? false,
                    'item'          => $templateSettings['item_table.column_item']->is_visible ?? true,
                    'pre_code'      => $templateSettings['item_table.column_pre_code']->is_visible ?? false,
                    'post_code'     => $templateSettings['item_table.column_post_code']->is_visible ?? false,
                    'barcode'       => $templateSettings['item_table.column_barcode']->is_visible ?? false,
                    'hsn_code'      => $templateSettings['item_table.column_hsn_code']->is_visible ?? false,
                    'purity'        => $templateSettings['item_table.column_purity']->is_visible ?? false,
                    'qty'           => $templateSettings['item_table.column_qty']->is_visible ?? true,
                    'metal_rate'    => $templateSettings['item_table.column_metal_rate']->is_visible ?? true,
                    'gross_wt'      => $templateSettings['item_table.column_gross_wt']->is_visible ?? true,
                    'net_wt'        => $templateSettings['item_table.column_net_wt']->is_visible ?? true,
                    'fine_wt'       => $templateSettings['item_table.column_fine_wt']->is_visible ?? false,
                    'size'          => $templateSettings['item_table.column_size']->is_visible ?? false,
                    'wastage'       => $templateSettings['item_table.column_wastage_percent']->is_visible ?? false,
                    'making'        => $templateSettings['item_table.column_making']->is_visible ?? true,
                    'gst_percent'   => $templateSettings['item_table.column_gst_percent']->is_visible ?? false,
                    'gst_amount'    => $templateSettings['item_table.column_gst_amount']->is_visible ?? false,
                    'other_charges' => $templateSettings['item_table.column_other_charges']->is_visible ?? true,
                    'diamond_amount' => $templateSettings['item_table.column_diamond_amount']->is_visible ?? true,
                    'stone_amount' => $templateSettings['item_table.column_stone_amount']->is_visible ?? true,
                    'amount'        => $templateSettings['item_table.column_amount']->is_visible ?? true,
                ];
                @endphp

                <div class="invoice-table">
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr class="ecommercetable">
                                    @if($columnVisibility['sr_no'])<th>{{ $columnLabels['sr_no'] }}</th>@endif
                                    @if($columnVisibility['category'])<th>{{ $columnLabels['category'] }}</th>@endif
                                    @if($columnVisibility['subcategory'])<th>{{ $columnLabels['subcategory'] }}</th>@endif
                                    @if($columnVisibility['item'])<th>{{ $columnLabels['item'] }}</th>@endif
                                    @if($columnVisibility['pre_code'])<th>{{ $columnLabels['pre_code'] }}</th>@endif
                                    @if($columnVisibility['post_code'])<th>{{ $columnLabels['post_code'] }}</th>@endif
                                    @if($columnVisibility['barcode'])<th>{{ $columnLabels['barcode'] }}</th>@endif
                                    @if($columnVisibility['hsn_code'])<th>{{ $columnLabels['hsn_code'] }}</th>@endif
                                    @if($columnVisibility['purity'])<th>{{ $columnLabels['purity'] }}</th>@endif
                                    @if($columnVisibility['qty'])<th>{{ $columnLabels['qty'] }}</th>@endif
                                    @if($columnVisibility['metal_rate'])<th>{{ $columnLabels['metal_rate'] }}</th>@endif
                                    @if($columnVisibility['gross_wt'])<th>{{ $columnLabels['gross_wt'] }}</th>@endif
                                    @if($columnVisibility['net_wt'])<th>{{ $columnLabels['net_wt'] }}</th>@endif
                                    @if($columnVisibility['fine_wt'])<th>{{ $columnLabels['fine_wt'] }}</th>@endif
                                    @if($columnVisibility['size'])<th>{{ $columnLabels['size'] }}</th>@endif
                                    @if($columnVisibility['wastage'])<th>{{ $columnLabels['wastage'] }}</th>@endif
                                    @if($columnVisibility['making'])<th>{{ $columnLabels['making'] }}</th>@endif
                                    @if($columnVisibility['gst_percent'])<th>{{ $columnLabels['gst_percent'] }}</th>@endif
                                    @if($columnVisibility['gst_amount'])<th>{{ $columnLabels['gst_amount'] }}</th>@endif
                                    @if($columnVisibility['other_charges'])<th>{{ $columnLabels['other_charges'] }}</th>@endif
                                    @if($columnVisibility['diamond_amount'])<th>{{ $columnLabels['diamond_amount'] }}</th>@endif
                                    @if($columnVisibility['stone_amount'])<th>{{ $columnLabels['stone_amount'] }}</th>@endif
                                    @if($columnVisibility['amount'])<th class="text-end">{{ $columnLabels['amount'] }}</th>@endif
                                </tr>
                            </thead>

                            <tbody>
                                @foreach($invoice->items as $item)
                                <tr>
                                    @if($columnVisibility['sr_no'])<td>{{ $loop->iteration }}</td>@endif
                                    @if($columnVisibility['category'])<td>{{ $item->category }}</td>@endif
                                    @if($columnVisibility['subcategory'])<td>{{ $item->subcategory }}</td>@endif
                                    @if($columnVisibility['item'])<td>{{ $item->item_name }}</td>@endif
                                    @if($columnVisibility['pre_code'])<td>{{ $item->pre_code }}</td>@endif
                                    @if($columnVisibility['post_code'])<td>{{ $item->post_code }}</td>@endif
                                    @if($columnVisibility['barcode'])<td>{{ $item->barcode }}</td>@endif
                                    @if($columnVisibility['hsn_code'])<td>{{ $item->hsn_code }}</td>@endif
                                    @if($columnVisibility['purity'])<td>{{ $item->purity }}</td>@endif
                                    @if($columnVisibility['qty'])<td>{{ $item->quantity }}</td>@endif
                                    @if($columnVisibility['metal_rate'])<td>{{ number_format($item->metal_rate,2) }}</td>@endif
                                    @if($columnVisibility['gross_wt'])<td>{{ number_format($item->gross_weight,3) }}</td>@endif
                                    @if($columnVisibility['net_wt'])<td>{{ number_format($item->net_weight,3) }}</td>@endif
                                    @if($columnVisibility['fine_wt'])<td>{{ number_format($item->fine_weight ?? 0,3) }}</td>@endif
                                    @if($columnVisibility['size'])<td>{{ $item->size }}</td>@endif
                                    @if($columnVisibility['wastage'])<td>{{ $item->wastage_percent }}%</td>@endif
                                    @if($columnVisibility['making'])<td>{{ number_format($item->making_price ?? 0,2) }}</td>@endif
                                    @if($columnVisibility['gst_percent'])<td>{{ $item->gst_percent }}%</td>@endif
                                    @if($columnVisibility['gst_amount'])<td>{{ number_format($item->gst_amount ?? 0,2) }}</td>@endif
                                    @if($columnVisibility['other_charges'])<td>{{ number_format($item->other_charges ?? 0,2) }}</td>@endif
                                    @if($columnVisibility['diamond_amount'])<td>{{ number_format($item->diamond_amount ?? 0,2) }}</td>@endif
                                    @if($columnVisibility['stone_amount'])<td>{{ number_format($item->stone_amount ?? 0,2) }}</td>@endif
                                    @if($columnVisibility['amount'])<td class="text-end">{{ number_format($item->final_price ?? 0,2) }}</td>@endif
                                </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>

            </div>
        </div>
        <div class="file-link">
            <button class="download_btn download-link">
                <i class="feather-download-cloud me-1"></i> <span>Download</span>
            </button>
            <a href="javascript:void(0)" onclick="printInvoiceSection()" class="print-link">
    <i class="feather-printer"></i> <span>Print</span>
</a>

        </div>

    </div>
    <script>
    function printInvoiceSection() {
        // const printContents = document.querySelector('.print-section').innerHTML;
        // const originalContents = document.body.innerHTML;

        // document.body.innerHTML = printContents;

        window.print();

        // document.body.innerHTML = originalContents;
        // window.location.reload(); // ensure JS & layout restored properly
    }
</script>

@endsection
