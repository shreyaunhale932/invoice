<?php $page = 'two-factor'; ?>
@extends('layout.mainlayout')
@section('content')
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content container-fluid">

            <div class="row">
                <div class="col-xl-3 col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="page-header">
                                <div class="content-page-header">
                                    <h5>Settings</h5>
                                </div>
                            </div>
                            <!-- Settings Menu -->
                            @component('components.settings-menu')
                            @endcomponent
                            <!-- /Settings Menu -->
                        </div>
                    </div>
                </div>

                <div class="col-xl-9 col-md-8">
                    <div class="card">
                        <div class="card-body two-factor w-100">
                            <div class="content-page-header factor">
                                <h5 class="setting-menu">Two-Factor Authentication Options</h5>
                            </div>
                            <div class="row">
                                <div class="col-sm-9">
                                    <div class="two-factor content p-0">
                                        <h5>Text Message</h5>
                                        <p>Use your mobile phone to receive security PIN.</p>
                                    </div>
                                </div>
                                <div class="col-sm-3 text-end">
                                    <div class="factor-checkbox">
                                        <div class="status-toggle">
                                            <input id="rating_1" class="check" type="checkbox" checked="">
                                            <label for="rating_1" class="checktoggle checkbox-bg factor">checkbox</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="two-factor icon">
                                <h5><img src="{{ URL::asset('/public/assets/img/two-factor-icon.svg') }}" alt="Icon"> Enabled,
                                    AUG 16, 2023</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Wrapper -->
@endsection
