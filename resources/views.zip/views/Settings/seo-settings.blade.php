<?php $page = 'seo-settings'; ?>
@extends('layout.mainlayout')
@section('content')
<!-- Page Wrapper -->
<div class="page-wrapper">
    <div class="content container-fluid">
        <!-- /Page Header -->
        <div class="row">
            <div class="col-xl-3 col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="page-header">
                            <div class="content-page-header">
                                <h5>Settings</h5>
                            </div>
                        </div>
                          <!-- Settings Menu -->
                          @component('components.settings-menu')
                          @endcomponent
                          <!-- /Settings Menu -->
                    </div>
                </div>
            </div>
            <div class="col-xl-9 col-md-8">
                <div class="card">
                    <div class="card-body w-100">
                        <div class="content-page-header">
                            <h5>SEO Settings</h5>
                        </div>
                        <form action="#">
                            <div class="row">
                                <div class="col-lg-12 col-sm-12">
                                    <div class="input-block mb-3">
                                        <label>Meta Title</label>
                                        <input type="text" class="form-control" placeholder="Enter Title">
                                    </div>
                                </div>
                                <div class="col-md-12 description-box">
                                    <div class="input-block mb-3">
                                          <label class="form-control-label">Meta Description</label>
                                          <textarea class="summernote form-control" placeholder="Type your message"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12 description-box">
                                    <div class="input-block mb-3">
                                          <label class="form-control-label">Meta keywords</label>
                                          <textarea class="summernote form-control" placeholder="Type your message"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="seo-setting">
                                        <h6 class="mb-3">Meta Image</h6>
                                        <div class="profile-picture">
                                            <div class="upload-profile">
                                                
                                                <div class="profile-img company-profile-img">
                                                    <img id="company-img" class="img-fluid me-0" src="{{URL::asset('/public/assets/img/companies/company-add-img.svg')}}" alt="profile-img">
                                                </div>
                                                <div class="add-profile">
                                                    <h5>Upload a New Photo</h5>
                                                    <span>Profile-pic.jpg</span>
                                                </div>
                                            </div>
                                            <div class="img-upload">
                                                <label class="btn btn-upload">
                                                    Upload <input type="file">
                                                </label>
                                                <a class="btn btn-remove">Remove</a>
                                            </div>										
                                        </div>
                                    </div>										
                                </div>
                                <div class="col-md-12">
                                    <div class="modal-footer p-0">
                                        <button type="button" data-bs-dismiss="modal" class="btn btn-back cancel-btn me-2">Cancel</button>
                                        <button type="submit" data-bs-dismiss="modal" class="btn btn-primary paid-continue-btn">Save Changes</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Wrapper -->

        <!-- Add New Modal -->
        <div class="modal custom-modal custom-lg-modal fade" id="add_custom" role="dialog">
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content">
                    <div class="modal-header border-0 pb-0">
                        <div class="form-header modal-header-title text-start mb-0">
                            <h4 class="mb-0">Add Email Template</h4>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        </button>
                    </div>
                    <div class="modal-body add">
                        <div class="addnew-modal">
                            <form action="#">
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12">
                                        <div class="input-block mb-3">
                                            <label>Title</label>
                                            <input type="text" class="form-control" placeholder="Enter Title">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-sm-12">
                                        <div class="input-block mb-3">
                                            <label>Subject</label>
                                            <input type="text" class="form-control" placeholder="Enter Subject">
                                        </div>
                                    </div>
                                    <div class="col-md-12 description-box">
                                        <div class="input-block mb-3">
                                              <label class="form-control-label">Template Content</label>
                                              <textarea class="summernote form-control" placeholder="Type your message"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            
                            <div class="modal-footer">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-back cancel-btn me-2">Cancel</button>
                                <button type="submit" data-bs-dismiss="modal" class="btn btn-primary paid-continue-btn">Add New</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Add Vendor Modal -->

        <!-- Edit Modal -->
        <div class="modal custom-modal  custom-lg-modal fade" id="edit_email" role="dialog">
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content">
                    <div class="modal-header border-0 pb-0">
                        <div class="form-header modal-header-title text-start mb-0">
                            <h4 class="mb-0">Edit Email Template</h4>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        </button>
                    </div>
                    <div class="modal-body add">
                        <div class="addnew-modal">
                            <form action="#">
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12">
                                        <div class="input-block mb-3">
                                            <label>Title</label>
                                            <input type="text" class="form-control" placeholder="Enter Title" value="Welcome Email">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-sm-12">
                                        <div class="input-block mb-3">
                                            <label>Subject</label>
                                            <input type="text" class="form-control" placeholder="Enter Subject" value="Welcome [Username]">
                                        </div>
                                    </div>
                                    <div class="col-md-12 description-box">
                                        <div class="input-block mb-3">
                                              <label class="form-control-label">Template Content</label>
                                              <textarea class="summernote form-control" placeholder="Type your message">Hi [User's Name],
                                                Welcome to Kanakku ! We're thrilled to have you on board. Get ready to experience a seamless and efficient way.
                                                To get started, Click here
                                                If you have any questions or need assistance, feel free to reach out to our support team at [support@example.com].</textarea>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            
                            <div class="modal-footer">
                                <button type="button" data-bs-dismiss="modal" class="btn btn-back cancel-btn me-2">Cancel</button>
                                <button type="submit" data-bs-dismiss="modal" class="btn btn-primary paid-continue-btn">Save Changes</button>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- /Edit Modal -->

        <!-- Delete Items Modal -->
    <div class="modal custom-modal fade modal-delete" id="delete_modal" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-header">
                        <div class="delete-modal-icon">
                            <span><i class="fe fe-check-circle"></i></span>
                        </div>
                        <h3>Are You Sure?</h3>
                        <p>You want delete email template</p>
                    </div>
                    <div class="modal-btn delete-action">
                        <div class="modal-footer justify-content-center p-0">
                            <button type="submit" data-bs-dismiss="modal" class="btn btn-primary paid-continue-btn me-2">Yes, Delete</button>
                            <button type="button" data-bs-dismiss="modal" class="btn btn-back cancel-btn">No, Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Delete Items Modal -->

    </div>
</div>

@endsection